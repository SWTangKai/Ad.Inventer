<template>
  <div class="header">
    <div class="header-item">
      <img src alt />
    </div>
    <div class="header-item">AI文案</div>
    <div class="header-item"></div>
  </div>
</template>

<script>
export default {
  name: "Header",
  props: {
    msg: String
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/* .header{
    height: 50px;
    background: pink;
} */
.header-item {
  height: 100%;
  width: 33%;
  /* background: pink; */
  float: left;
  color: grey;
  font-size: large;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
