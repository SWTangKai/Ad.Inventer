<template>
  <a-tabs defaultActiveKey="1" @change="callback">
    <a-tab-pane tab="简单模式" key="1">
      <div class="content">
        <div>
          <a-select mode="tags" style="width: 100%" @change="handleChange" placeholder="请输入关键词">
            <a-select-option v-for="i in keywords" :key="i">{{i}}</a-select-option>
          </a-select>
        </div>
        <div>
          <a-button @click="handleGen">文本生成</a-button>
        </div>
        <div style="padding:30px; ">
          <a-card
            title="生成结果"
            :loading="loading"
            :bordered="false"
            style="width: 300px; margin: autoS;"
          >{{ gencontent }}</a-card>
        </div>
        <div></div>
      </div>
    </a-tab-pane>
    <a-tab-pane tab="高级模式" key="2" forceRender>
        <a-list
            bordered
            itemLayout="horizontal"
            :dataSource="data"
        >
        <a-list-item slot="renderItem" slot-scope="item, index">
        <a-list-item-meta
            description="Ant Design, a design language for background applications, is refined by Ant UED Team"
        >
            <a slot="title" href="https://vue.ant.design/">{{item.title}}</a>
            <!-- <a-avatar slot="avatar" src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" /> -->
        </a-list-item-meta>
        </a-list-item>
    </a-list>

    </a-tab-pane>

  </a-tabs>
</template>

<script>
/* eslint-disable */

const API = "http://deecamp.tangkailh.cn:10080/";

const data = [
  {
    title: 'Ant Design Title 1',
  },
  {
    title: 'Ant Design Title 2',
  },
  {
    title: 'Ant Design Title 3',
  },
  {
    title: 'Ant Design Title 4',
  },
]

export default {
  name: "Content",
  props: {
    msg: String
  },
  data() {
    return {
      gencontent: "12314",
      queryWords: "",
      keywords: [],
      loading: true,
      data
    };
  },
  mounted() {
    this.LoadKeyword();
  },
  methods: {
    LoadKeyword() {
      this.$http.get(API + "deecamp_keywords").then(res => {
        console.log(res.data);
        this.keywords = res.data.slice(0, 100);
      });
    },
    handleChange(value) {
      // console.log(`selected ${value}`);
      this.queryWords = value;
    },
    handleGen() {
      let me = this;
      //   window.vass =
      this.$http
        .get(
          API + "deecamp?keywords=" + this.queryWords.join(" ") + "&aspects=a"
          // "https://www.easy-mock.com/mock/5d44e8585324514551c72b01/deecamp/gen"
        )
        .then(response => {
          console.log(response.data);
          this.gencontent = response.data;
          me.loading = false;
        });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/* div {
  margin: 10px;
} */

.content {
  height: 100%;
}

h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
